
from instagrapi import Client
from instagrapi.exceptions import LoginRequired
import os, time
import pyotp

# Dane logowania z Render (zmienne środowiskowe)
USERNAME = os.getenv("IG_USERNAME")
PASSWORD = os.getenv("IG_PASSWORD")
TOTP_SECRET = os.getenv("IG_2FA_SECRET")  # Sekret z Google Authenticator

# Hashtagi do działania bota
HASHTAGS = ["modelka", "glamour", "instamodel", "polskamodelka"]
MESSAGE_TEXT = "Cześć! Dzięki za follow ❤️ Jeśli jesteś zainteresowany współpracą, napisz śmiało!"

def login():
    cl = Client()
    try:
        # TOTP (2FA) – generowanie kodu jednorazowego
        otp_code = pyotp.TOTP(TOTP_SECRET).now()
        cl.login(USERNAME, PASSWORD, verification_code=otp_code)
        print("✅ Zalogowano")
        return cl
    except Exception as e:
        print("❌ Błąd logowania:", e)
        return None

def like_and_follow(cl):
    for tag in HASHTAGS:
        medias = cl.hashtag_medias_recent(tag, amount=5)
        for media in medias:
            cl.media_like(media.id)
            if not cl.user_following(media.user.pk):
                cl.user_follow(media.user.pk)
            print(f"❤️ Liked & followed: {media.user.username}")
            time.sleep(10)

def dm_new_followers(cl):
    my_user_id = cl.user_id_from_username(USERNAME)
    followers = cl.user_followers(my_user_id, amount=20)
    for user_id, user_info in followers.items():
        threads = cl.direct_threads()
        if not any(user_info.username in t.users for t in threads):
            try:
                cl.direct_send(MESSAGE_TEXT, [user_id])
                print(f"💬 Sent message to {user_info.username}")
                time.sleep(10)
            except Exception as e:
                print(f"❌ Error sending to {user_info.username}: {e}")

if __name__ == "__main__":
    client = login()
    if client:
        like_and_follow(client)
        dm_new_followers(client)
